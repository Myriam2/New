package Class;

public class Main {



	public static void main(String[] args) {
		//Accueil fenetre= new Accueil();
		//Stage primaryStage = new Stage();
		int [] tab={0,12,15,18,-1,-5,15,10};
		VectorHelper vecteur =new VectorHelper(8,tab);
		vecteur.min_max();
		vecteur.multipl(10);
		vecteur.affich_vect();
		vecteur.invert_vector();
		vecteur.affich_vect();
		//primaryStage= fenetre.get_satge();
		//primaryStage.show();



    }
}
