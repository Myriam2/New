package application;

import Class.*;
import javafx.event.ActionEvent;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Accueil  {

	/**** creation des 4 button de l'accueil ****/
	
    private final Button tri = new Button("Trier un vecteur");
    private final Button somme= new Button("Sommer deux vecteur");
    private final Button inverse = new Button("Inverser un vecteur");
    private final Button min_max = new Button("Min et max d'un vecteur");
    private final Button multip= new Button("Multiplication d'un vecteur");
    private final Button quitter = new Button("Quitter");
    /*********************************************/
    private Stage primaryStage;//le stage qui va contenir la fenetre de l'accueil
    private FlowPane root;

    /**************** Constructeur ******************/
    public Accueil()
    {
    	int [] tab={0,12,15,18,-1,-5,1};
		VectorHelper vecteur =new VectorHelper(7,tab);

      	 this.primaryStage = new Stage();//creation du stage
      	 this.primaryStage.initStyle(StageStyle.UTILITY);
 //** affectation de la police et la taille du text pour les 4 button de l'accueil
      	 tri.setFont(new Font("Lucida Calligraphy Italic", 15));
         somme.setFont(new Font("Lucida Calligraphy Italic", 15));
         inverse.setFont(new Font("Lucida Calligraphy Italic", 15));
         min_max.setFont(new Font("Lucida Calligraphy Italic", 15));
         multip.setFont(new Font("Lucida Calligraphy Italic", 15));
         quitter.setFont(new Font("Lucida Calligraphy Italic", 15));
//** affectation de la forme pour chaque button sour forme d'ellipse avec la taille des rayons (100,15)

         tri.setShape(new Ellipse(100, 15));
         somme.setShape(new Ellipse(100, 15));
         inverse.setShape(new Ellipse(100, 15));
         min_max.setShape(new Ellipse(100, 15));
         multip.setShape(new Ellipse(100, 15));
         quitter.setShape(new Ellipse(100, 15));
//** modifier la taille pre�f�r�es pour chaque regions pour les 4 button

         tri.setPrefSize(350, 30);
         somme.setPrefSize(350, 30);
         inverse.setPrefSize(350, 30);
         min_max.setPrefSize(350, 30);
         multip.setPrefSize(350, 30);
         quitter.setPrefSize(350, 30);
//** affectation pour chaque button l'action qu'il doit faire lors du clique

         tri.setOnAction((ActionEvent event) -> {
                  vecteur.invert_vector();

                  String s = "";
                  for(int i=0;i<vecteur.get_taille();i++)
                  {
                	  s=s+vecteur.get_tab_case(i)+ " ; ";
                  }

                  fenetre f = new fenetre("Le vecteur tri�e ",s);

         });
         somme.setOnAction((ActionEvent event) -> {
        	 vecteur.invert_vector();

             String s = "";
             for(int i=0;i<vecteur.get_taille();i++)
             {
           	  s=s+vecteur.get_tab_case(i)+ " ; ";
             }

             fenetre f = new fenetre("La somme de deux vecteur ",s);
        });
         inverse.setOnAction((ActionEvent event) -> {
        	 vecteur.invert_vector();
        	 String s = "";
             for(int i=0;i<vecteur.get_taille();i++)
             {
           	  s=s+vecteur.get_tab_case(i)+ " ; ";
             }

             fenetre f = new fenetre("Le vecteur inverse ",s);
          });
         min_max.setOnAction((ActionEvent event) -> {
        	 vecteur.min_max();

             String s = "";
             s="\n   la valeur du min = "+vecteur.get_min_vector()+"\n   la valeur du max = "+vecteur.get_max_vector();

             fenetre f = new fenetre("Les valeur min et max d'un vecteur",s);
          });
         multip.setOnAction((ActionEvent event) -> {
        	 vecteur.multipl(10);

             String s = "";
             for(int i=0;i<vecteur.get_taille();i++)
             {
           	  s=s+vecteur.get_tab_case(i)+ " ; ";
             }

             fenetre f = new fenetre("Le vecteur multipli�e ",s);
          });
          quitter.setOnAction((ActionEvent event) -> {
        	  primaryStage.close();// on ferme le stage de la fenetre d'accueil
              event.consume();
         });
         // Creation de root qui contient les 4 buttons alligner verticalement
         root = new FlowPane(Orientation.VERTICAL, 35, 35,tri, somme,inverse,min_max,multip,quitter,
                 new Label(), new Label());

         root.setAlignment(Pos.BOTTOM_CENTER);// positioner root au centre

 //** on d�finit la forme est centr�e dans la largeur ou la hauteur de la R�gion a vrai

         tri.setCenterShape(true);
         somme.setCenterShape(true);
         inverse.setCenterShape(true);
         quitter.setCenterShape(true);
         Image image2 = new Image(getClass().getResourceAsStream("img.png"));// creation de l'image a partir de la source img.png
 //** affectation du background de la fenetre d'accueil la taille et l'image du fond
         root.setBackground(new Background(new BackgroundImage(image2, BackgroundRepeat.NO_REPEAT,
        		 BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
        		 new BackgroundSize(650, 600, false, false, false, false))));
         Scene scene = new Scene(root, 650, 600);// affecter le root dans la scence qui contient la fenetre avec les dimension de la largeur et la longueur
         scene.setFill(Color.TRANSPARENT);// mettre la couleur transparente
         primaryStage.setTitle("Welcome");//affecter le titre de la fenetre
         primaryStage.setScene(scene);// affecter la scene du stage de l'accueil
         primaryStage.setResizable(false);// desactiver le redimentionement de la fenetre
         primaryStage.centerOnScreen();// la positionner ou centre de l'ecran
     }
    /************ Getter *********/
    public Stage get_satge()//retourne le stage qui contien la fenetre
    {
    	return(this.primaryStage);
    }
}
