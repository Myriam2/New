package application;

import javafx.application.Application;
import javafx.stage.Stage;


public class Main extends Application {
    @Override
    public void start(Stage initStage)
    {
    		// creation de la fenetre d'accueil
            Accueil m = new Accueil();
       	    Stage stage = m.get_satge();
       	    stage.show();// afficher le stage de la fenetre d'accueil

    }
//***** la fonction qui lance le main
    public static void main(String[] args) {
        launch(args);
    }
}