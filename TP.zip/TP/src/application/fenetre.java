package application;

import java.util.Optional;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

public class fenetre {
	
	// fenetre de type boite de dialogue
    public fenetre(String titre,String rps)
    {
    	Alert alert = new Alert(javafx.scene.control.Alert.AlertType.NONE);//creation de l'aletre
	    alert.setTitle(titre);//affectation du titre
	    alert.setContentText(rps);

	    ButtonType buttonType1 = new ButtonType("OK",ButtonData.OK_DONE);

	    alert.getButtonTypes().setAll(buttonType1);
	    Optional<ButtonType> result = alert.showAndWait();

	}



}
